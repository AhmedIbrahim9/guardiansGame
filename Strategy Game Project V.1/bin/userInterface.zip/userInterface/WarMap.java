package userInterface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import game.Archer;
import game.Chariot;
import game.Knight;
import game.SpearMan;
import game.Warrior;
import server.Connection;
import server.MapUnit;
import server.commandToSend;


public class WarMap extends JFrame implements Runnable {
	private static final long serialVersionUID = 4954849721314145851L;
	
	
	//*****************************************Variables*****************************************\
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) screenSize.getWidth();
		int height = (int) screenSize.getHeight();
		
		String identity;

				
		public static ArrayList<MapUnit> units = new ArrayList<MapUnit>();
			
		UnitsNumberSelecter unitsSelect;

		public static int SoldierNumber = game.Warrior.WarriorsList.size() + 5;
		public static int ArhcerNumber = game.Archer.ArcherList.size() + 5;
		public static int SpearmanNumber = game.SpearMan.SpearManList.size() + 5;
		public static int KnightNumber =  game.Knight.KnightList.size() + 5;
		public static int ChariotNumber =  game.Chariot.ChariotList.size() + 5;
		
		
	//*****************************************Panels*****************************************\
	JPanel statesPanel = new JPanel();	
	JPanel mapPanel    = new JPanel();
	
	//*****************************************Icons*****************************************\
	ImageIcon mapIcon  = new ImageIcon(new ImageIcon("Images & Sounds/map/sqr.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon image    = new ImageIcon(new ImageIcon("Images & Sounds\\map\\warMap.png").getImage().getScaledInstance(width, height , Image.SCALE_DEFAULT));
	
	ImageIcon buttonIcon  = new ImageIcon(new ImageIcon("Images & Sounds/Images/button1.png").getImage().getScaledInstance(200, 130, Image.SCALE_DEFAULT));
	ImageIcon buttonIcon2 = new ImageIcon(new ImageIcon("Images & Sounds/Images/button2.png").getImage().getScaledInstance(200, 130, Image.SCALE_DEFAULT));
	
	ImageIcon soldierIcon = new ImageIcon(new ImageIcon("Images & Sounds/symbols/sword.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
	ImageIcon archerIcon  = new ImageIcon(new ImageIcon("Images & Sounds/symbols/bow.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
	ImageIcon knightIcon  = new ImageIcon(new ImageIcon("Images & Sounds/symbols/knight.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
	ImageIcon chariotIcon = new ImageIcon(new ImageIcon("Images & Sounds/symbols/chariot.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
	ImageIcon spearIcon   = new ImageIcon(new ImageIcon("Images & Sounds/symbols/spear.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
	
	static ImageIcon Worrior = new ImageIcon(new ImageIcon("Images & Sounds/Soldiers at war/Warriors at war left 2.png").getImage().getScaledInstance(90, 90, Image.SCALE_DEFAULT));
	static ImageIcon Archer  = new ImageIcon(new ImageIcon("Images & Sounds/Soldiers at war/Archers at Left.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
	static ImageIcon Knight  = new ImageIcon(new ImageIcon("Images & Sounds/Soldiers at war/Knights at Left.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
	static ImageIcon Chariot = new ImageIcon(new ImageIcon("Images & Sounds/Soldiers at war/Chariot at Left.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
	static ImageIcon Spear   = new ImageIcon(new ImageIcon("Images & Sounds/Soldiers at war/SpearMan at Left.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));

	ImageIcon flagIcon   = new ImageIcon(new ImageIcon("Images & Sounds/symbols/flag.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
	
	String folder = "Nation 2";
	ImageIcon nationIcon = new ImageIcon(new ImageIcon(folder + "/nation.png").getImage().getScaledInstance(250, 250, Image.SCALE_DEFAULT));
	
	ImageIcon HPIcon   = new ImageIcon(new ImageIcon("Images & Sounds/HP/10.png").getImage().getScaledInstance(250, 15, Image.SCALE_DEFAULT));
	
	//*****************************************Labels*****************************************\
	JLabel map[][] = new JLabel[12][12];
	JLabel background = new JLabel(image);
	
	JLabel soldierLabel  = new JLabel(soldierIcon);
	JLabel archerLabel   = new JLabel(archerIcon);
	JLabel knightLabel   = new JLabel(knightIcon);
	JLabel chariotLabel  = new JLabel(chariotIcon);
	JLabel spearmanLabel  = new JLabel(spearIcon);
	
	JLabel flagLabel  = new JLabel(flagIcon);
	
	public static JLabel soldierCount  = new JLabel(String.valueOf(SoldierNumber));
	public static JLabel archerCount   = new JLabel(String.valueOf(ArhcerNumber));
	public static JLabel knightCount   = new JLabel(String.valueOf(KnightNumber));
	public static JLabel chariotCount  = new JLabel(String.valueOf(ChariotNumber));
	public static JLabel spearmanCount = new JLabel(String.valueOf(SpearmanNumber));

	
	JLabel nationLabel   = new JLabel(nationIcon);
	
	JLabel HP = new JLabel(HPIcon);
	
	JLabel selectionPos = new JLabel("Selected Position ");
	
	JLabel ID = new JLabel("Selected unit ID : ");


	//*****************************************Buttons*****************************************\
	JButton Ready = new JButton(buttonIcon);
	JButton showHide   = new JButton(buttonIcon);
	JButton Deploy   = new JButton(buttonIcon);
	
	//*****************************************Clips*****************************************\
	AudioInputStream audioInputStream ;
	Clip clip; 
	
	static boolean visible = true;
	static boolean isDeployed = false;
	static boolean isSelected = false;
	public static boolean isTurn = true;
	static String[] str;
	private int numOfTurns = 0;
	
	public WarMap(String type) throws IOException
	{ 
		identity = type;

		//Main frame settings
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH); 
		setUndecorated(true);
		setVisible(true);
		setLayout(null);
		setTitle("Guardians : The First Journey");
		setBackground(Color.BLACK);
		
		
	
		//Panels Layouts
		statesPanel.setLayout(null);
		statesPanel.setBounds(0, 0, 58, height);
		statesPanel.setBackground(Color.GRAY);
		add(statesPanel);
		
	
		mapPanel.setLayout(null);
		mapPanel.setBounds(59, 0 , width - 59, height);
		mapPanel.setBackground(Color.GREEN);
		add(mapPanel);
		
		
		initMap();
	    initStatesPanel();
	    
	 	repaint();
	    
	 			
	}
	
		//------Initialize states Panel components
		private void initStatesPanel()
		{	
			int y = 75;
		
			flagLabel.setBounds(10 , 15 ,50 ,50);
			flagLabel.addMouseListener(new MouseAdapter(){
				
				@Override
				public void mouseClicked(MouseEvent e)
				{
					dispose();
				}
				
			});
		
			
			soldierLabel.setBounds(10 , 60 + y ,40 ,40);
			soldierCount.setBounds(10 , 110 + y,55 ,25);
			soldierCount.setFont(new Font(getName() , Font.BOLD , 15));
					
			archerLabel.setBounds(10 , 160 + y,40 ,40);
			archerCount.setBounds(10 , 210 + y,55 ,25);
			archerCount.setFont(new Font(getName() , Font.BOLD , 15));	
					
			spearmanLabel.setBounds(10 , 260 + y ,40 ,40);
			spearmanCount.setBounds(10 , 310 + y,55 ,25);
			spearmanCount.setFont(new Font(getName() , Font.BOLD , 15));
					
			knightLabel.setBounds(10 , 360 + y,40 ,40);
			knightCount.setBounds(10 , 410 + y ,55 ,25);
			knightCount.setFont(new Font(getName() , Font.BOLD , 15));
					
			chariotLabel.setBounds(10, 460 + y ,40 ,40);
			chariotCount.setBounds(10 , 510 + y ,55 ,25);
			chariotCount.setFont(new Font(getName() , Font.BOLD , 15));

					
			
			statesPanel.add(flagLabel);
					
			statesPanel.add(soldierLabel);
			statesPanel.add(archerLabel);
			statesPanel.add(spearmanLabel);
			statesPanel.add(knightLabel);
			statesPanel.add(chariotLabel);

					
			statesPanel.add(soldierCount);
			statesPanel.add(archerCount);
			statesPanel.add(spearmanCount);
			statesPanel.add(knightCount);
			statesPanel.add(chariotCount);
			
			
			

			
			}
		
		//------Initialize map
		private void initMap()
		{
			background.setBounds(0,0,mapPanel.getWidth(),mapPanel.getHeight());
			mapPanel.add(background);
			
			nationLabel.setBounds(1600 , 10 , 250 , 250);
			background.add(nationLabel);
			
			HP.setBounds(1600 , 265 , 250 , 15);
			background.add(HP);
			
			selectionPos.setBounds(30 , 30 , 400 , 25);
			selectionPos.setFont(new Font(getName() , Font.BOLD , 25));
			background.add(selectionPos);
			
			ID.setBounds(30 , 60 , 400 , 25);
			ID.setFont(new Font(getName() , Font.BOLD , 25));
			background.add(ID);
			
			showHide.setBounds(1650, 930, 200, 60);
			showHide.setFont(new Font(getName() , Font.BOLD , 25));
			showHide.setHorizontalTextPosition(JLabel.CENTER);
			showHide.setForeground(Color.WHITE);
			showHide.setText("Show/Hide");
			showHide.setBackground(Color.GRAY);
			showHide.setBorder(null);
			showHide.addMouseListener(new MouseAdapter(){
				
				@Override
				public void mouseClicked(MouseEvent e)
				{
					if(visible)
					{
						showHide(0);
						visible = false;
					} else {
						
						showHide(1);
						visible = true;
					}
					
					try {
						 playClick();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						
				}
				
				@Override
				public void mouseEntered(MouseEvent e)
				{
					showHide.setIcon(buttonIcon2);
				}
				
				@Override
				public void mouseExited(MouseEvent e)
				{
					showHide.setIcon(buttonIcon);
				}
			});
			background.add(showHide);
			
			
			Ready.setBounds(1650, 1000, 200, 60);
			Ready.setFont(new Font(getName() , Font.BOLD , 25));
			Ready.setHorizontalTextPosition(JLabel.CENTER);
			Ready.setForeground(Color.WHITE);
			Ready.setText("Ready");
			Ready.setBackground(Color.GRAY);
			Ready.setBorder(null);
			Ready.addMouseListener(new MouseAdapter(){
				
				@Override
				public void mouseClicked(MouseEvent e)
				{			
					
					numOfTurns = 0;  
					
					try {
						 playClick();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
				}
				
				@Override
				public void mouseEntered(MouseEvent e)
				{
					Ready.setIcon(buttonIcon2);
				}
				
				@Override
				public void mouseExited(MouseEvent e)
				{
					Ready.setIcon(buttonIcon);
				}
				
			});
			background.add(Ready);
			
			Deploy.setBounds(1650, 860, 200, 60);
			Deploy.setFont(new Font(getName() , Font.BOLD , 25));
			Deploy.setHorizontalTextPosition(JLabel.CENTER);
			Deploy.setForeground(Color.WHITE);
			Deploy.setText("Deploy");
			Deploy.setBackground(Color.GRAY);
			Deploy.setBorder(null);
			Deploy.addMouseListener(new MouseAdapter(){
				
				@Override
				public void mouseClicked(MouseEvent e)
				{
					if(allowDeployment())
					{
						showHide(0);
						visible = false;
						
						Deploy.setEnabled(false);
						isDeployed = true;
											
					
					try {
						 playClick();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
						
						
				}
				
				@Override
				public void mouseEntered(MouseEvent e)
				{
					Deploy.setIcon(buttonIcon2);
				}
				
				@Override
				public void mouseExited(MouseEvent e)
				{
					Deploy.setIcon(buttonIcon);
				}
			});
			background.add(Deploy);
	 
			int x = 0;
			int y = 0;
			
			for(int i=0 ; i<12; i++)
			{	
				if(i == 0)
				{
					x=10;
					y=490;
				} else if(i == 1) {
					x=80;
					y=530;
					
				} else if(i == 2) {
					x=160;
					y=575;
					
				} else if(i == 3) {
					x=240;
					y=620;
					
				} else if(i == 4) {
					x=320;
					y=665;
				} else if(i == 5) {
					x=400;
					y=710;
					
				} else if(i == 6) {
					x=480;
					y=755;
				} else if(i == 7) {
					x=560;
					y=800;
					
				} else if(i == 8) {		
					x=640;
					y=845;
				} else if(i == 9) {
					x=720;
					y=890;
				} else if(i == 10) {		
					x=800;
					y=935;
				} else if(i == 11) {
					x=880;
					y=980;		
				}
				
				for(int j=0 ; j<12 ; j++)
				{
					map[i][j] = new JLabel(mapIcon);
					map[i][j].setBounds(x ,y ,90 , 90);		
					
					if(identity == "Attacker")
					{
						if(i == 10 || i == 11)
							map[i][j].setVisible(true);	
						else
							map[i][j].setVisible(false);	
						
					} else if(identity == "Deffender") {
						
						if(i == 0 || i == 1)
							map[i][j].setVisible(true);	
						else
							map[i][j].setVisible(false);	
					}
										
					map[i][j].putClientProperty("deployed", false);
					map[i][j].setText(String.valueOf(i) + " " + String.valueOf(j) );
					map[i][j].setHorizontalTextPosition(JLabel.CENTER);
					map[i][j].setForeground(Color.white);
					background.add(map[i][j]);
					
				map[i][j].addMouseListener(new MouseAdapter(){
				@Override
				public void mouseClicked(MouseEvent e)
				{
					isTurn = true; //temp remove later
								
						selectionPos.setText("Selected Position " +((JLabel)e.getSource()).getText());
						
						
						if(!isDeployed &&  !((boolean) ((JLabel)e.getSource()).getClientProperty("deployed")))
						{
							unitsSelection( (JLabel)e.getSource()  );
							
						} else if (isDeployed && numOfTurns < 3) {
							
							if(isTurn)
							{
																			
							if(!isSelected)
							{
								if(((JLabel)e.getSource()).getIcon() != mapIcon)  //to show the movments
								{					
									showHide(0);
									
									ImageIcon icon =  (ImageIcon) (((JLabel)e.getSource()).getIcon());
									
									str = (((JLabel)e.getSource()).getText()).split(" ");
									
									if(icon == Worrior)							
										showMovments(1 , Integer.parseInt(str[0]) , Integer.parseInt(str[1]));							
									else if ((icon == Archer)) 							
										showMovments( 2, Integer.parseInt(str[0]) , Integer.parseInt(str[1]));								
									 else if ((icon == Spear)) 
										 showMovments( 3, Integer.parseInt(str[0]) , Integer.parseInt(str[1]));		
									 else if ((icon == Knight)) 
										 showMovments( 4, Integer.parseInt(str[0]) , Integer.parseInt(str[1]));		
									 else if ((icon == Chariot)) 
										 showMovments( 5, Integer.parseInt(str[0]) , Integer.parseInt(str[1]));	
									
								
										isSelected = true;
							
								}
								
							} else if(((JLabel)e.getSource()).getIcon() != mapIcon && isSelected) { //to unselect a unit
	
								showHide(0);
								isSelected = false;
								
							} else {
								
								String next[] = ((JLabel)e.getSource()).getText().split(" ");  //next position
												
								ImageIcon icon = (ImageIcon) map[Integer.parseInt(str[0])][Integer.parseInt(str[1])].getIcon(); //selected unit icon
								
								if(map[Integer.parseInt(next[0])][Integer.parseInt(next[1])].getIcon() == mapIcon) //to prevent movment to occupied locations
								{
									map[Integer.parseInt(next[0])][Integer.parseInt(next[1])].setIcon(icon); //setting the next location icon to the selected unit icon
									
									map[Integer.parseInt(str[0])][Integer.parseInt(str[1])].setIcon(mapIcon); //setting the previous locatin to a map icon
									
									for(MapUnit unit1 : units)
											unit1.position = ((JLabel)e.getSource()).getText();  //updating the unit position to the updated location

									isSelected = false;
									
									showHide(0);
									
									numOfTurns++;
								}
																						
							}
						}
						
						try {
							 playClick();
							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
					
					}
				});
					
					x+= 80;
					y-= 45;
					
				}//inner for loop
				
			}//outer for loop
						
		}
		
		//------Play click Function
		private void playClick() throws UnsupportedAudioFileException, IOException, LineUnavailableException
		{
			audioInputStream = AudioSystem.getAudioInputStream(new File("Images & Sounds/Sounds/click.wav").getAbsoluteFile());
			clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			clip.start();
		}
		
		//----Update map
		public void updateMap()
		{
			
					for(MapUnit unit : units)
					{
						System.out.println(unit.id);
						String pos = unit.position;
						
						String posSplit[] = new String[2];
						
						posSplit[0] = new String();
						posSplit[1] = new String();
						
						posSplit = pos.split(" ");
						
						String type = unit.type;
						
						switch(type)
						{
						  case "Soldier" :
							  
							  map[Integer.parseInt(posSplit[0])][Integer.parseInt(posSplit[1])].setIcon(Worrior);
							
							  break;
							  
						  case "Archer" :
							  
							  map[Integer.parseInt(posSplit[0])][Integer.parseInt(posSplit[1])].setIcon(Archer);
							  break;
						  case "Spearman" :
							  map[Integer.parseInt(posSplit[0])][Integer.parseInt(posSplit[1])].setIcon(Spear);
							  break;
						  case "Knight" :
							  map[Integer.parseInt(posSplit[0])][Integer.parseInt(posSplit[1])].setIcon(Knight);
							  break;
						  case "Chariot" :
							  map[Integer.parseInt(posSplit[0])][Integer.parseInt(posSplit[1])].setIcon(Chariot);
							  break;
									
						}
						
						  map[Integer.parseInt(posSplit[0])][Integer.parseInt(posSplit[1])].setVisible(true);
						repaint();
					}
					repaint();
				}
		
		
		//------Hide/show 
		private void showHide(int x)
		{
			for(int i=0 ; i<12 ; i++)
				for(int j=0 ; j<12 ; j++)
					if(identity.equals("Attacker"))
					{
						if((i == 10 || i == 11) && x == 1 )
						  map[i][j].setVisible(true);
						else if((i == 10 || i == 11) && x == 0 && map[i][j].getIcon() == mapIcon)
							map[i][j].setVisible(false);
						else if (isDeployed && map[i][j].getIcon() == mapIcon)
							map[i][j].setVisible(false);
									
					} else if (identity.equals("Deffender")) {
						
						if((i == 0 || i == 1) && x == 1)
						  map[i][j].setVisible(true);
						else if(!isDeployed && (i == 0 || i == 1) && x == 0 && map[i][j].getIcon() == mapIcon)
							map[i][j].setVisible(false);
						else if (isDeployed && map[i][j].getIcon() == mapIcon)
							map[i][j].setVisible(false);
					}
						
		}

		//-----check if any units is deployed
		private boolean allowDeployment()
		{
			for(int i=0 ; i<12 ; i++)
				for(int j=0 ; j<12 ; j++)
					if(map[i][j].getIcon() != mapIcon)
						return true;
			
			return false;
		}
		//------Hide/show movments
		private void showMovments(int type , int x ,int y)
		{
			if(identity.equals("Attacker"))
			{
				switch(type)
				{
				   case 1:
					   
					  for(int i=0 ; i<12 ; i++)
					     for(int j=0 ; j<12 ; j++)
					    	 if( (i == (x-1) && j == (y-1)) || (i == (x) && j == (y-1)) || (i == (x+1) && j == (y-1)) || (i == (x-1) && j == (y)) ||
					    	     (i == (x+1) && j == (y)) || (i == (x-1) && j == (y+1)) || (i == (x) && j == (y+1)) || (i == (x+1) && j == (y+1)) )
					    		   map[i][j].setVisible(true);
					  break; 		 
		
				   case 2:				   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x-2) && j == (y-2)) || (i == (x-2) && j == (y-1)) || (i == (x-2) && j == (y))   || (i == (x-2) && j == (y+1)) ||
						    	     (i == (x-2) && j == (y+2)) || (i == (x-1) && j == (y-2)) || (i == (x-1) && j == (y+2)) || (i == (x) && j == (y-2))   ||
						    	     (i == (x) && j == (y+2))   || (i == (x+1) && j == (y-2)) || (i == (x+1) && j == (y+2)) || (i == (x+2) && j == (y-2)) ||
						    	     (i == (x+2) && j == (y-1)) || (i == (x+2) && j == (y))   || (i == (x+2) && j == (y+1)) || (i == (x+2) && j == (y+2) ))
						    		   map[i][j].setVisible(true);
						  break; 		   
					   
				   case 3:
					   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x-2) && j == (y-2)) || (i == (x-1) && j == (y-1)) || (i == (x-2) && j == (y)) || (i == (x-1) && j == (y)) ||
						    	     (i == (x+2) && j == (y-2)) || (i == (x+1) && j == (y-1)) || (i == (x-1) && j == (y+1)) || (i == (x-2) && j == (y+2)) ||
						    	     (i == (x+1) && j == (y+1)) || (i == (x+2) && j == (y+2)) )
						    		   map[i][j].setVisible(true);
						  break; 	
						  
				   case 4:		   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x-1) && j == (y-1)) || (i == (x) && j == (y-1)) || (i == (x-1) && j == (y+1)) || (i == (x+1) && j == (y-1)) ||
						    	     (i == (x) && j == (y+1)) || (i == (x+1) && j == (y+1))  )
						    		   map[i][j].setVisible(true);
						  break; 		
				   case 5:
					   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x) && j == (y+1)) || (i == (x) && j == (y+2)) || (i == (x) && j == (y+3)) || (i == (x) && j == (y-1)) ||
						    	     (i == (x) && j == (y-2)) || (i == (x) && j == (y-3)) || (i == (x+1) && j == (y)) || (i == (x+2) && j == (y)) ||
						    	     (i == (x+3) && j == (y)) || (i == (x-1) && j == (y)) || (i == (x-2) && j == (y)) || (i == (x-3) && j == (y)) )
						    		   map[i][j].setVisible(true);
						  break; 		     
					
				}
				
			} else if(identity.equals("Deffender")) {
				
				switch(type)
				{
				   case 1:
					   
					  for(int i=0 ; i<12 ; i++)
					     for(int j=0 ; j<12 ; j++)
					    	 if( (i == (x-1) && j == (y-1)) || (i == (x) && j == (y-1)) || (i == (x+1) && j == (y-1)) || (i == (x-1) && j == (y)) ||
					    	     (i == (x+1) && j == (y)) || (i == (x-1) && j == (y+1)) || (i == (x) && j == (y+1)) || (i == (x+1) && j == (y+1)) )
					    		   map[i][j].setVisible(true);
					  break; 		 
		
				   case 2:				   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x-2) && j == (y-2)) || (i == (x-2) && j == (y-1)) || (i == (x-2) && j == (y))   || (i == (x-2) && j == (y+1)) ||
						    	     (i == (x-2) && j == (y+2)) || (i == (x-1) && j == (y-2)) || (i == (x-1) && j == (y+2)) || (i == (x) && j == (y-2))   ||
						    	     (i == (x) && j == (y+2))   || (i == (x+1) && j == (y-2)) || (i == (x+1) && j == (y+2)) || (i == (x+2) && j == (y-2)) ||
						    	     (i == (x+2) && j == (y-1)) || (i == (x+2) && j == (y))   || (i == (x+2) && j == (y+1)) || (i == (x+2) && j == (y+2) ))
						    		   map[i][j].setVisible(true);
						  break; 		   
					   
				   case 3:
					   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x-2) && j == (y-2)) || (i == (x-1) && j == (y-1)) || (i == (x-2) && j == (y)) || (i == (x-1) && j == (y)) ||
						    	     (i == (x+2) && j == (y-2)) || (i == (x+1) && j == (y-1)) || (i == (x-1) && j == (y+1)) || (i == (x-2) && j == (y+2)) ||
						    	     (i == (x+1) && j == (y+1)) || (i == (x+2) && j == (y+2)) )
						    		   map[i][j].setVisible(true);
						  break; 	
						  
				   case 4:		   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x-1) && j == (y-1)) || (i == (x) && j == (y-1)) || (i == (x-1) && j == (y+1)) || (i == (x+1) && j == (y-1)) ||
						    	     (i == (x) && j == (y+1)) || (i == (x+1) && j == (y+1))  )
						    		   map[i][j].setVisible(true);
						  break; 		
				   case 5:
					   
						  for(int i=0 ; i<12 ; i++)
						     for(int j=0 ; j<12 ; j++)
						    	 if( (i == (x) && j == (y+1)) || (i == (x) && j == (y+2)) || (i == (x) && j == (y+3)) || (i == (x) && j == (y-1)) ||
						    	     (i == (x) && j == (y-2)) || (i == (x) && j == (y-3)) || (i == (x+1) && j == (y)) || (i == (x+2) && j == (y)) ||
						    	     (i == (x+3) && j == (y)) || (i == (x-1) && j == (y)) || (i == (x-2) && j == (y)) || (i == (x-3) && j == (y)) )
						    		   map[i][j].setVisible(true);
						  break; 		     
					
				}
			}
			
			repaint();

		}
		
		
		//-----Deploy Units to selected location
		public void unitsSelection(JLabel label){
			
			MapUnit unit = new MapUnit();
			
			String curr = label.getText();
			
			try {
				showHide(0);	
				showHide.setEnabled(false);
				
				unitsSelect = new UnitsNumberSelecter();
				unitsSelect.setBounds(550 , 250 , 534,465);
				unitsSelect.setVisible(true);
				background.add(unitsSelect);
				
				repaint();
			
				unitsSelect.getJConfim().addMouseListener(new MouseAdapter(){
					
					@Override
					public void mouseClicked(MouseEvent e)
					{									
							
						showHide(1);	
						showHide.setEnabled(true);

							try {
								 playClick();
								} catch (Exception e1) {
									e1.printStackTrace();
								}
							
							if(unitsSelect.getNumber() != 0)
							{
								label.putClientProperty("deployed", true);
								//unit.id = id;
								unit.type = unitsSelect.getType();
								unit.number = unitsSelect.getNumber();
								unit.position = curr;
								
								switch(unit.type){
								case "Soldier":
									Warrior w = new Warrior();
									unit.health = w.Health * unit.number;
									unit.damage = w.Damage * unit.number;
									units.add(unit);
									label.setIcon(Worrior);
									break;
								case "Archer":
									Archer a = new Archer();
									unit.health = a.Health * unit.number;
									unit.damage = a.Damage * unit.number;
									units.add(unit);
									label.setIcon(Archer);
									break;
								case "Spearman":
									SpearMan s = new SpearMan();
									unit.health = s.Health * unit.number;
									unit.damage = s.Damage * unit.number;
									units.add(unit);
									label.setIcon(Spear);
									break;
								case "Knight":
									Knight k = new Knight();
									unit.health = k.Health * unit.number;
									unit.damage = k.Damage * unit.number;
									units.add(unit);
									label.setIcon(Knight);
									break;
								case "Charriot":
									Chariot c = new Chariot();
									unit.health = c.Health * unit.number;
									unit.damage = c.Damage * unit.number;
									units.add(unit);
									label.setIcon(Chariot);
									break;
								}			
								
							} else {
								label.setIcon(mapIcon);
							}
							
							unitsSelect.setVisible(false);
							unitsSelect = null;
					}
				});
				
			} catch (IOException e2) {
				e2.printStackTrace();
			}
						
		}

		@Override
		public void run() {
			while(true)
			{
				  commandToSend command = new commandToSend();
				  command.commandType = "MapUnits";
				  command.commandValue = units;
				  
				  try {
					Connection.output.writeObject(command);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				  
				updateMap();
				repaint();
				System.out.println("Thread is active");
				
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}

}
