package userInterface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import game.Nations;
import server.Connection;
import server.commandToSend;

public class NationSelect extends JPanel{

	private static final long serialVersionUID = 1L;
	private BufferedImage image = ImageIO.read(new File("Images & Sounds\\Images\\nations.jpg"));

	private JLabel Diablo  = new JLabel();
	private JLabel Minerva = new JLabel();


	NationSelect() throws IOException
	{
		setPreferredSize(new Dimension(LogRegScreen.width , LogRegScreen.height));
		setLayout(null);
		
		Minerva.setBounds(140, 425, 400, 580);
		Diablo.setBounds(1430, 425, 400, 580);	
		
	    Minerva.setVisible(true);    
	    Diablo.setVisible(true);
	
	    add(Diablo);
	    add(Minerva);  

	  Diablo.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	   
	    		Nations.setName(1);
	    		/*commandToSend command = new commandToSend();
	    		command.commandType = "Nation";
    			command.commandValue = 1;
	    		try {
					Connection.output.writeObject(command);
				} catch (IOException e2) {
					e2.printStackTrace();
				}
	    		try {
					@SuppressWarnings("unused")
					UserCity city = new UserCity();
				} catch (Exception e1) {
					e1.printStackTrace();
				} */
	    		
	    		try {
					@SuppressWarnings("unused")
					UserCity city = new UserCity();
				} catch (Exception e1) {
					e1.printStackTrace();
				} //temp
	    		
	    		Screen.musicClip.stop();
	    			
	    	}   		
		});
	  Minerva.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	   
	    		Nations.setName(2);
	    			
	    		/*commandToSend command = new commandToSend();
	    		command.commandType = "Nation";
    			command.commandValue = 1;
	    		try {
					Connection.output.writeObject(command);
				} catch (IOException e2) {
					e2.printStackTrace();
				}
	    		try {
					@SuppressWarnings("unused")
					UserCity city = new UserCity();
				} catch (Exception e1) {
					e1.printStackTrace();
				} */
	    		
	    		try {
					@SuppressWarnings("unused")
					UserCity city = new UserCity();
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
	    		
	    		Screen.musicClip.stop();
	    			
	    	}   		
		});
	    
		repaint();	
	}
	
	public void paintComponent(Graphics g)
	{
		
		g.drawImage(image, 0, 0, LogRegScreen.width , LogRegScreen.height, Diablo); 
		super.paintComponents(g);

	}
	 
}

